# DaftarNama

Daftarnama is a domain registrar.

## Install the Module

1. You can install the module via composer:

    ```
    composer require parent_repository/daftarnama
    ```

2. OR upload the source code to a /components/modules/daftarnama/ directory within
your Blesta installation path.

    For example:

    ```
    /var/www/html/blesta/components/modules/daftarnama/
    ```

3. Log in to your admin Blesta account and navigate to
> Settings > Modules

4. Find the DaftarNama module and click the "Install" button to install it

5. You're done!

